module.exports = {
    entry: "./main.js",
    output: {
        filename: "build.js"
    },
    target: 'node',
    resolve: {
        extensions: ['.js'],
        modules: ['node_modules'],
    },
    module: {
        rules: [
            {
                test: /\.js$/,
                loader: 'babel-loader',
            }
        ],
    },
    stats: {
        colors: true
    },
    devtool: 'source-map'
};
